package os.Model;

public class OsBean {

	private int swnumber;
	private String swname;
	private int assetcount;
	private int assetcountpc;
	private int notassetcount;
	private int notassetcountpc;
	
	public int getSwnumber() {
		return swnumber;
	}
	public void setSwnumber(int swnumber) {
		this.swnumber = swnumber;
	}
	public String getSwname() {
		return swname;
	}
	public void setSwname(String swname) {
		this.swname = swname;
	}
	public int getAssetcount() {
		return assetcount;
	}
	public void setAssetcount(int assetcount) {
		this.assetcount = assetcount;
	}
	public int getAssetcountpc() {
		return assetcountpc;
	}
	public void setAssetcountpc(int assetcountpc) {
		this.assetcountpc = assetcountpc;
	}
	public int getNotassetcount() {
		return notassetcount;
	}
	public void setNotassetcount(int notassetcount) {
		this.notassetcount = notassetcount;
	}
	public int getNotassetcountpc() {
		return notassetcountpc;
	}
	public void setNotassetcountpc(int notassetcountpc) {
		this.notassetcountpc = notassetcountpc;
	}
	
}
