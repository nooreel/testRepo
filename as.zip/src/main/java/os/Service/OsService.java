package os.Service;

import java.util.List;

import os.Model.OsBean;

public interface OsService {
	public abstract List<OsBean> getOsList();
	
}
