package SystemConfig.Service;

public interface EmployeeService {
	public abstract void DeleteEmployee(String employeenumber);
}
