package Equipment.Model;

public class EquipmentBean {
	private String equipmentid;
	private String equipmenttype;
	private String equipmentip;
	private int assetyn;
	private int nclientsetup;
	private String employeenumber;
	
	public String getEquipmentid() {
		return equipmentid;
	}
	public void setEquipmentid(String equipmentid) {
		this.equipmentid = equipmentid;
	}
	public String getEquipmenttype() {
		return equipmenttype;
	}
	public void setEquipmenttype(String equipmenttype) {
		this.equipmenttype = equipmenttype;
	}
	public String getEquipmentip() {
		return equipmentip;
	}
	public void setEquipmentip(String equipmentip) {
		this.equipmentip = equipmentip;
	}
	public int getAssetyn() {
		return assetyn;
	}
	public void setAssetyn(int assetyn) {
		this.assetyn = assetyn;
	}
	public int getNclientsetup() {
		return nclientsetup;
	}
	public void setNclientsetup(int nclientsetup) {
		this.nclientsetup = nclientsetup;
	}
	public String getEmployeenumber() {
		return employeenumber;
	}
	public void setEmployeenumber(String employeenumber) {
		this.employeenumber = employeenumber;
	}
	
	
}
