package Equipment.Service;

import Equipment.Model.EquipmentBean;

public interface EquipmentService {
	public abstract void EquipmentRegist(EquipmentBean bean);
}
