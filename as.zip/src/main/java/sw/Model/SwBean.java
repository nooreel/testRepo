package sw.Model;

public class SwBean {
	private int swnumber;
	private String swname;
	private String swversion;
	private String bit;
	private int active;
	private String maker;
	private String used;
	private int quantity;
	private String swtype;
	private String equipmentid;
	
	
	
	
	public String getEquipmentid() {
		return equipmentid;
	}
	public void setEquipmentid(String equipmentid) {
		this.equipmentid = equipmentid;
	}
	public String getSwtype() {
		return swtype;
	}
	public void setSwtype(String swtype) {
		this.swtype = swtype;
	}
	public int getSwnumber() {
		return swnumber;
	}
	public void setSwnumber(int swnumber) {
		this.swnumber = swnumber;
	}
	public String getSwname() {
		return swname;
	}
	public void setSwname(String swname) {
		this.swname = swname;
	}
	public String getSwversion() {
		return swversion;
	}
	public void setSwversion(String swversion) {
		this.swversion = swversion;
	}
	public String getBit() {
		return bit;
	}
	public void setBit(String bit) {
		this.bit = bit;
	}
	public int getActive() {
		return active;
	}
	public void setActive(int active) {
		this.active = active;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
