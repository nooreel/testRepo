package stswtb.Model;

public class SwVersionManagementBean {
	private int assetdaesang;
	private int assetsetupcount;
	private int notassetdaesang;
	private int notassetsetupcount;
	private String swname;
	private int swnumber;
	private String bit;
	private String swversion;
	
	
	
	public String getBit() {
		return bit;
	}
	public void setBit(String bit) {
		this.bit = bit;
	}
	public String getSwversion() {
		return swversion;
	}
	public void setSwversion(String swversion) {
		this.swversion = swversion;
	}
	public int getSwnumber() {
		return swnumber;
	}
	public void setSwnumber(int swnumber) {
		this.swnumber = swnumber;
	}
	public String getSwname() {
		return swname;
	}
	public void setSwname(String swname) {
		this.swname = swname;
	}
	public int getAssetdaesang() {
		return assetdaesang;
	}
	public void setAssetdaesang(int assetdaesang) {
		this.assetdaesang = assetdaesang;
	}
	public int getAssetsetupcount() {
		return assetsetupcount;
	}
	public void setAssetsetupcount(int assetsetupcount) {
		this.assetsetupcount = assetsetupcount;
	}
	public int getNotassetdaesang() {
		return notassetdaesang;
	}
	public void setNotassetdaesang(int notassetdaesang) {
		this.notassetdaesang = notassetdaesang;
	}
	public int getNotassetsetupcount() {
		return notassetsetupcount;
	}
	public void setNotassetsetupcount(int notassetsetupcount) {
		this.notassetsetupcount = notassetsetupcount;
	}
	
	

	
}
