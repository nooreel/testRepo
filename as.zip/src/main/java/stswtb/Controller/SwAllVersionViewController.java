package stswtb.Controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.swing.plaf.synth.SynthSpinnerUI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import Paging.SwAllVersionPaging;
import stswtb.Model.SwVersionManagementBean;
import stswtb.Service.StswtbService;

@Controller
public class SwAllVersionViewController {

	@Autowired
	StswtbService stswtbservice;
	
	@RequestMapping(value="GetSwAllVersion.stswtb")
	public void GetSwAllVersion(@RequestParam(value="swname") String swname
			, HttpServletResponse response
			,@RequestParam(value="pageNumber",required=false) String textpageNumber) {
		
		Map<String, String> map=new HashMap<String,String>();
		map.put("swname", swname);
		
		
		int totalCount=stswtbservice.getTotalCountFromSwAllVersion(map);
		
		SwAllVersionPaging paging=new SwAllVersionPaging(textpageNumber, totalCount, "GetSwAllVersion.stswtb", null);
		
		List<SwVersionManagementBean> swalist=stswtbservice.getSwAllVersion(paging,map);
		
		response.setContentType("text/html;charset=UTF-8"); 
		
		try {
			PrintWriter out=response.getWriter();
		out.println("<table class='table table-bordered table-striped'>");
		out.println("<tr>\r\n" + 
				"			<td rowspan=2>S/W��</td>\r\n" + 
				"			<td rowspan=2>BIT</td>\r\n" + 
				"			<td rowspan=2>����</td>\r\n" + 
				"			<td colspan=2>�ڻ�</td>\r\n" + 
				"			<td colspan=2>���ڻ�</td>\r\n" + 
				"		</tr>");	
		out.println("<tr>\r\n" + 
				"			<td>��ġ</td>\r\n" + 
				"			<td>��</td>\r\n" + 
				"			<td>��ġ</td>\r\n" + 
				"			<td>��</td>\r\n" + 
				"		</tr>");	
		for(int i=0;i<swalist.size();i++) {
			out.println("<tr>");
			out.println("<td>"+swalist.get(i).getSwname()+"</td>");
			out.println("<td>"+swalist.get(i).getBit()+"</td>");
			out.println("<td>"+swalist.get(i).getSwversion()+"</td>");
			out.println("<td>"+swalist.get(i).getAssetsetupcount()+"</td>");
			double doubleassetsetupcount=swalist.get(i).getAssetsetupcount();
			out.println("<td>"+doubleassetsetupcount/swalist.get(i).getAssetdaesang()*100+"%</td>");
			out.println("<td>"+swalist.get(i).getNotassetsetupcount()+"</td>");
			double doublenotassetsetupcount=swalist.get(i).getNotassetsetupcount();
			out.println("<td>"+doublenotassetsetupcount/swalist.get(i).getNotassetdaesang()*100+"%</td>");
			out.println("</tr>");
			
		}
		out.println("<tr>");
		out.println("<td colspan=4>"+paging.getPagingHtml()+"</td>");
		out.println("<td colspan=3 align='right'>"+paging.getBeginRow()+"-"+paging.getEndRow()+" of "+paging.getTotalCount()+" items"
			+"</td>");
		out.println("</tr>");
		out.println("</table>");
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
